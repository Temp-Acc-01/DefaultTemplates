class AppRouteName {
  static const String getStarted = "/get-started";
  static const String home = "/home";
  static const String register = '/register';
  static const String signin = '/sign_in';
}

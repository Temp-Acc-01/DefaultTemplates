import 'package:flutter/material.dart';

class SearchMovie extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Search Movie',style: TextStyle(color: Colors.white)),
    );
  }
}
